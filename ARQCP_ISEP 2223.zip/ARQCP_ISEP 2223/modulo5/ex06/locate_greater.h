int locate_greater(Student *s, int minimum, int *greater_grades);
