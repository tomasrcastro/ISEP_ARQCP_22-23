int count_odd_matrix (int **m, int y, int k);
