char *new_str(char str[80]);
