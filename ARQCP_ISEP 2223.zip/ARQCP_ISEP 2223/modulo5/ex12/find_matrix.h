int find_matrix(int **m, int y, int k, int num);
