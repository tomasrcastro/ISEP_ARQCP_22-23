void str_cat(void);
