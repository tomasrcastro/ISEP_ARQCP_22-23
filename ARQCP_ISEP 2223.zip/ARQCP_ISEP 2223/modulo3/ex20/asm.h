int count_max(void);
