int remove_duplicates();
