int sort_without_reps();
