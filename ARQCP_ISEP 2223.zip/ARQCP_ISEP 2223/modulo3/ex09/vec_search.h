short* vec_search(void);
