int seven_count(void);
