void str_copy_porto2(void);
