unsigned char vec_zero(void);
