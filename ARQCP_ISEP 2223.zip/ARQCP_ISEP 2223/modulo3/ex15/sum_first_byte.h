int sum_first_byte();
