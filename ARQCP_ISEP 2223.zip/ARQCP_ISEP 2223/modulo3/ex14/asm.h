int exists(void);
