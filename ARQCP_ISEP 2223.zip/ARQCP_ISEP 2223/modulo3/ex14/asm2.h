int vec_diff(void);
