void frequencies(void);
