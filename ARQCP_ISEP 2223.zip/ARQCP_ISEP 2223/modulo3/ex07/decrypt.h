int decrypt(void);
