long vec_sum_even(void);
