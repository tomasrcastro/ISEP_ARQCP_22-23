long test_even(void);
