void keep_positives(void);
