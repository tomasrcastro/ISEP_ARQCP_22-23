long vec_avg(void);
