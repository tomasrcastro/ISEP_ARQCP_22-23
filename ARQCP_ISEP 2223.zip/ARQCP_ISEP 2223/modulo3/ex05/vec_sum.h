long vec_sum(void);
