int vec_greater10(void);
