int calc(int a, int *b, int c);
