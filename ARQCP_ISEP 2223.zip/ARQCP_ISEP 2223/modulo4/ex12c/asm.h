int vec_count_bits_one(short *ptr, int num);
int count_bits_one(int x);
