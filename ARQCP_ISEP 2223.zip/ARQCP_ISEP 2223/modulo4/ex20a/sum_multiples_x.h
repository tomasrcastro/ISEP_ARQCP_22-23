int sum_multiples_x(char *vec, int x);
