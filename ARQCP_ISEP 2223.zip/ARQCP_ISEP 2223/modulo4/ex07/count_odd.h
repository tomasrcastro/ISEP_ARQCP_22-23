int count_odd(char *vec, int n);
