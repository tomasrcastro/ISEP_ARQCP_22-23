int test_equal(char *a, char *b);
