int rotate_left(int num, int nbits);
