int rotate_right(int num, int nbits);
