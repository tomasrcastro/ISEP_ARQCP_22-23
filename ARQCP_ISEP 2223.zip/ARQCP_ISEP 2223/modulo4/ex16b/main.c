#include <stdio.h>
#include "asm.h"

int main(){
	
	int res = join_bits(1, 2, 3);
	
	printf("%d\n", res);
	
	return 0;
	
}	
