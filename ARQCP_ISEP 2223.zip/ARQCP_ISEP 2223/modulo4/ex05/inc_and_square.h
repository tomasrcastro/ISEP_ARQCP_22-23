int inc_and_square(int *v1, int v2);
