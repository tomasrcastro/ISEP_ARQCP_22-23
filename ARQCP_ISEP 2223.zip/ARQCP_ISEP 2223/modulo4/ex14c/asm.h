void reset_2bits(int *ptr, int pos);
