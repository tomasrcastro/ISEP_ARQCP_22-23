unsigned int greater_date(unsigned int date1, unsigned int date2);
