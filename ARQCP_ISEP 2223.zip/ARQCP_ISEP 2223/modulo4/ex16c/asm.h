int mixed_sum(int a, int b, int pos);
