int sum_smaller(int num1, int num2, int *smaller);
