#include <stdio.h>
#include "asm.h"

int n = 2;

int main(void){

    int res = sum_n2(n);

    printf("%d\n", res);

    return 0;
}
