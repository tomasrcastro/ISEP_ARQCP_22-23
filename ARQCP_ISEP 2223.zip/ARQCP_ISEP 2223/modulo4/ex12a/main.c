#include <stdio.h>
#include "count_bits_one.h"

int main(){
	
	int x = 3;
	
	int res = count_bits_one(x);
	
	printf("%d\n", res);
	
	return 0;
	
}
