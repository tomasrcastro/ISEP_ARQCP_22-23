int count_bits_one(int x);
