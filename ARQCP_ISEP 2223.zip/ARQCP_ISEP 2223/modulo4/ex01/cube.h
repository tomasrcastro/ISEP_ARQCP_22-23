long cube(int x);
