int calculate(int a, int b);
