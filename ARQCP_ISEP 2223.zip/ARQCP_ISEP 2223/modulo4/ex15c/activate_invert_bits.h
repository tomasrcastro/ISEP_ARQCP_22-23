int activate_invert_bits(int a, int left, int right);
