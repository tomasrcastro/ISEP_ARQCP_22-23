void changes_vec(int *ptrvec, int num);
