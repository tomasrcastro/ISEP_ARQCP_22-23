int greatest(int a, int b, int c, int d);
