void changes (int *ptr);
