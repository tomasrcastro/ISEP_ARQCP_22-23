#include <stdio.h>
#include "call_proc.h"

int main(){
	int resultado = call_proc(33,9998,5311,100);
	
	printf("Resultado: %d.\n", resultado);
	
	return 0;
}
