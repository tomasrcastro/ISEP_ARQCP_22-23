int call_proc(int a, int b, short c, char d);
