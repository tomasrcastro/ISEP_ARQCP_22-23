void proc(int x1, int *p1, int x2, int *p2, short x3, short *p3, char x4, char *p4);
