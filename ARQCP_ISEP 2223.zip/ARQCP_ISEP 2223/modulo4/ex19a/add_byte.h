void add_byte (char x, int *vec1, int *vec2);
