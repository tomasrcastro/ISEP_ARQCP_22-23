int reset_bit(int *ptr, int pos);
