#include <stdio.h>
#include "join_bits.h"

int main(){
	
	int res = join_bits(1, 2, 3);
	
	printf("%d\n", res);
	
	return 0;
	
}	
