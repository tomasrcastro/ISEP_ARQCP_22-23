int join_bits(int a, int b, int pos);
