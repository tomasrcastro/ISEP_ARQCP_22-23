int distance (char *a, char *b);
