int activate_bits(int a, int left, int right);
