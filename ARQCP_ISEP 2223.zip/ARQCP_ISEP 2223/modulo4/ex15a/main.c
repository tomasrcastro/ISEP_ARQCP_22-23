#include <stdio.h>
#include "activate_bits.h"

int main(){
	int resultado = activate_bits(-3,-6,0);
	
	printf("Resultado: %d.\n", resultado);
	
	return 0;
}
