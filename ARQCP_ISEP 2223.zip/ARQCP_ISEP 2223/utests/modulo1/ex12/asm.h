#ifndef ASM_H 
#define ASM_H 
void capitalize( char * p); 
#endif 

