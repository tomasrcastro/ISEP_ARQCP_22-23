#ifndef ASM_H 
#define ASM_H 
void power_ref(int* x, int y); 
#endif 

