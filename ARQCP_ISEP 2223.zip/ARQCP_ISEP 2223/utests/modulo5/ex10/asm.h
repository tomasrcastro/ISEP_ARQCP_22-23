#ifndef ASM_H 
#define ASM_H 
char *  new_str(char *p1); 
#endif 

