#ifndef ASM_H 
#define ASM_H 
int distance(char *p1,char *p2); 
#endif 

