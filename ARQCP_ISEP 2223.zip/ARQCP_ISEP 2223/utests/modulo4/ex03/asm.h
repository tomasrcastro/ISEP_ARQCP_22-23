#ifndef ASM_H 
#define ASM_H 
int greatest(int x,int y, int z, int w); 
#endif 

