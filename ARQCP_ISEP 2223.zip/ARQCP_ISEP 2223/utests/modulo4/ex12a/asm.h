#ifndef ASM_H 
#define ASM_H 
int count_bits_one(int x); 
#endif 

