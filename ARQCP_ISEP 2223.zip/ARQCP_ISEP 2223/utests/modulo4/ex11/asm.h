#ifndef ASM_H 
#define ASM_H 
int call_proc( int a, int b , short c, char d ); 
#endif 

