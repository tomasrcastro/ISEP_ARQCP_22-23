#ifndef ASM_H 
#define ASM_H 
int calculate(int x,int y ); 
#endif 

