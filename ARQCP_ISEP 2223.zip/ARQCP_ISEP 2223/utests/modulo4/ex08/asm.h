#ifndef ASM_H 
#define ASM_H 
int calc(int a,int *b,int c ); 
#endif 

