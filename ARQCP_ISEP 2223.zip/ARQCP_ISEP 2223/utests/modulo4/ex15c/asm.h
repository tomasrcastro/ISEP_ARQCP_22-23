#ifndef ASM_H 
#define ASM_H 
int activate_bits( int a, int left, int right); 
int activate_invert_bits( int a, int left, int right); 
#endif 

