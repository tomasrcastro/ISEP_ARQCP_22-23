#ifndef FUNC_H 
#define FUNC_H 
int rotate_left( int x , int num_bits ); 
int rotate_right( int x , int num_bits ); 
#endif 

