#ifndef FUNC_H 
#define FUNC_H 
int join_bits( int a, int b, int pos); 
#endif 

