#ifndef FUNC_H 
#define FUNC_H 
int activate_bits( int a, int left, int right); 
#endif 

