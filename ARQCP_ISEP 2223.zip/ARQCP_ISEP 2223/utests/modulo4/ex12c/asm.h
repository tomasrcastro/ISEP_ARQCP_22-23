#ifndef ASM_H 
#define ASM_H 

int count_bits_one(int a ); 
int vec_count_bits_one(short * ptr , int num ); 
#endif 

