 #ifndef ASM_H
  #define ASM_H
  char check_num(void);
#endif
