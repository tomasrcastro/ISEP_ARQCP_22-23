 #ifndef ASM_H
  #define ASM_H
  int getArea(void);
#endif
