 #ifndef ASM_H
  #define ASM_H
  int steps(void);
#endif
