 #ifndef ASM_H
  #define ASM_H
  char test_flags(void);
#endif
