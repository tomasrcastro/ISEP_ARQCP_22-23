 #ifndef ASM_H
  #define ASM_H
  int needed_time(void);
#endif
