 #ifndef ASM_H
  #define ASM_H
  int sum_v2(void);
  long sum_v3(void); 
  extern long op3; 
  extern long op4; 
  
#endif
