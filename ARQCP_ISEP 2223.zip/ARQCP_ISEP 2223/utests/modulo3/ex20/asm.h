#ifndef ASM_H 
#define ASM_H 
int count_max(void); 
#endif 

