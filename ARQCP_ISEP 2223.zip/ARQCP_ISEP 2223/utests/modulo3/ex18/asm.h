#ifndef ASM_H 
#define ASM_H 
int  sort_without_reps(void); 
#endif 

