#ifndef ASM_H 
#define ASM_H 
int sum_first_byte(void); 
#endif 

