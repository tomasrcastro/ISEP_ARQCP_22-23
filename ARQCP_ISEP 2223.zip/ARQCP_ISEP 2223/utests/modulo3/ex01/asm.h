#ifndef ASM_H 
#define ASM_H 
int seven_count(void); 
#endif 

