#ifndef ASM_H 
#define ASM_H 
void  swap(void); 
#endif 

