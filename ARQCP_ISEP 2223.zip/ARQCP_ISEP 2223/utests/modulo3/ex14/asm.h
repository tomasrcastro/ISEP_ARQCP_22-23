#ifndef ASM_H 
#define ASM_H 
int exists(void); 
int vec_diff(void); 
#endif 

