#ifndef ASM_H 
#define ASM_H 
void  frequencies(void); 
#endif 

