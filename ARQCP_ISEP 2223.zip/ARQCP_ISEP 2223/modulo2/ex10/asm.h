#ifndef EX10_H
#define EX10_H
long long sum3ints();
#endif
