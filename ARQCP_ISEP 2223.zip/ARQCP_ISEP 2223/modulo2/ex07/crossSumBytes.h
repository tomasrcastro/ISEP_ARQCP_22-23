short crossSumBytes();
