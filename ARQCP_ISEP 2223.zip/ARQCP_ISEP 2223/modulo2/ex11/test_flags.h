#ifndef TESTFLAGS_H
#define TESTFLAGS_H

char test_flags();

#endif
