#ifndef NEEDEDTIME_H
#define NEEDEDTIME_H

int needed_time();

#endif
