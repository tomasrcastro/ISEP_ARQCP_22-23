#ifndef EX08_H
#define EX08_H
short crossSumBytes(void);
extern short s1, s2;
#endif
