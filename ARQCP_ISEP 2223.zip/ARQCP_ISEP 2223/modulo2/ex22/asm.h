#ifndef EX22_H
#define EX22_H
int f();
int f2();
int f3();
int f4();
#endif