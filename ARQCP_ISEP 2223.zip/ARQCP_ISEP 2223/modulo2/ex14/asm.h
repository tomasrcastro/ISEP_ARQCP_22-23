#ifndef EX14_H
#define EX14_H
int getArea();
extern int length1, length2, height;
#endif
