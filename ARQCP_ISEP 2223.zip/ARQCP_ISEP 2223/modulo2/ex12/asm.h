#ifndef EX12_H
#define EX12_H
char isMultiple();
#endif
