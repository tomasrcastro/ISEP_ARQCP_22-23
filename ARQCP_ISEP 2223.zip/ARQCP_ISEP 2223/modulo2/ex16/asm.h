#ifndef EX16_H
#define EX16_H
long steps(void);
#endif
