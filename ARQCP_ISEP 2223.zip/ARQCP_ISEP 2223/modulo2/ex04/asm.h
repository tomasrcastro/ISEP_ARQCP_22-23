#ifndef EX04_H
#define EX04_H
long sum_v3();
extern long op3, op4;
#endif
