#include <stdio.h>
#include "asm.h"

int n = 2;
int i = 1;
int res;

int main(){
	res = somat();
	printf("Result: %d\n", res);
	return 0;
}
