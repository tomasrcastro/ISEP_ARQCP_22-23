#ifndef EX18_H
#define EX18_H
int somat();
#endif
