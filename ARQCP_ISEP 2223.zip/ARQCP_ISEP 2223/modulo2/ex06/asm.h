#ifndef EX06_H
#define EX06_H
short concatBytes(void);
#endif
