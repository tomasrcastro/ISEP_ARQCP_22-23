#ifndef EX02_H
#define EX02_H
int sum_v2(void);
#endif
