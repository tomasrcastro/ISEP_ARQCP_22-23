#ifndef NEWSALARY_H
#define NEWSALARY_H

int new_salary();

#endif
