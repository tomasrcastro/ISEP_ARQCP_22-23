#ifndef ASM_H
#define ASM_H
void sum(void);
#endif
