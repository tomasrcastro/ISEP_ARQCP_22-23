#ifndef COMPUTE_H
#define COMPUTE_H

int compute();

#endif
