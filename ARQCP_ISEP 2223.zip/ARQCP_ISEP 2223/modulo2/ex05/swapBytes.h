#ifndef SWAPBYTES_H
#define SWAPBYTES_H

short swapBytes();

#endif
