#ifndef EX02_H
#define EX02_H
int sum(void);
#endif