#ifndef EX20_H
#define EX20_H
char check_num();
#endif
