#ifndef SUMANDSUBTRACT_H
#define SUMANDSUBTRACT_H

long sum_and_subtract();

#endif
