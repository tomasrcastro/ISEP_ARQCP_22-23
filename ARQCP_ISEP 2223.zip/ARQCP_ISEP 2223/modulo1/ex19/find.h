#ifndef EX19_H
#define EX19_H

char *find_word(char *word, char *initial_addr);

#endif
