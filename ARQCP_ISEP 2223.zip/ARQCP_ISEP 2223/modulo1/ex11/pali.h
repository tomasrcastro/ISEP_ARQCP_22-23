#ifndef EX11_H
#define EX11_H

int palindrome(char* str);

#endif
