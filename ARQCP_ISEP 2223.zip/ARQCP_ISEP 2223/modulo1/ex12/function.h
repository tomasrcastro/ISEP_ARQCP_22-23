#ifndef EX12_H
#define EX12_H
void capitalize (char *str);
#endif
