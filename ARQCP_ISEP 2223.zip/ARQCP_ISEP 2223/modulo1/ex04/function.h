#ifndef EX04_H
#define EX04_H

void upper1(char *str);

#endif
