#ifndef EX06_H
#define EX06_H
void power_ref(int* x, int y);

#endif
