#ifndef EX03_H
#define EX03_H

int sum_even( int*p, int num);

#endif
