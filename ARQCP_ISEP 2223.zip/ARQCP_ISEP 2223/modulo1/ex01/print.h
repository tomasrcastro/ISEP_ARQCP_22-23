#ifndef EX01_H
#define EX01_H

void print(int x, int* xPtr, float y, int vec[]);

#endif
