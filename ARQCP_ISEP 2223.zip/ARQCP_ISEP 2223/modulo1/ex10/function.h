#ifndef EX10_H
#define EX10_H
int odd_sum(int *p);
#endif
