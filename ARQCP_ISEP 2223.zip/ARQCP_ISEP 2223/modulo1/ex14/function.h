#ifndef EX14_H
#define EX14_H
void frequencies (float *grades, int n, int *freq);
#endif
