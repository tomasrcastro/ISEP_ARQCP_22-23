#include <stdio.h>

void inc_nsets(){
	extern int numberSets;
	
	numberSets++;
}
