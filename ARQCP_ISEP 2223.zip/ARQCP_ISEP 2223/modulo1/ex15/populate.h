#ifndef EX15_H
#define EX15_H

void populate(int *vec, int num, int limit);

#endif
