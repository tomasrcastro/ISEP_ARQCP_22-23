#ifndef EX15_H
#define EX15_H

int check(int x, int y, int z);

#endif
