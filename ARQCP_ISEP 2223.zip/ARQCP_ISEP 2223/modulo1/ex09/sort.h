#ifndef EX09_H
#define EX09_H

int sort_without_reps(int *scr, int n, int *dest);

#endif
