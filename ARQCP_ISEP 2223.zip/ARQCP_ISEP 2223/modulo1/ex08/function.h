#ifndef EX08_H
#define EX08_H
void array_sort2(int *vec, int n);
#endif
