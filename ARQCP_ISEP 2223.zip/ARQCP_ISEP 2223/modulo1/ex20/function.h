#ifndef EX20_H
#define EX20_H
void find_all_words(char* str, char* word, char** addrs);
#endif
