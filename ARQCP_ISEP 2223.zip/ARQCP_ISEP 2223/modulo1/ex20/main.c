#include <stdio.h>
#include "function.h"

int main(){
	
