#ifndef EX13_H
#define EX13_H

int where_is(char *str, char c, int *p);

#endif
