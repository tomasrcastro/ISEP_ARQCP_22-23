#ifndef EX17_H
#define EX17_H

void swap(int* vec1, int* vec2, int size);

#endif
