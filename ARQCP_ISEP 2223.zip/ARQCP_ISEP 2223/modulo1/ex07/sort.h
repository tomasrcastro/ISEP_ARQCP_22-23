#ifndef EX07_H
#define EX07_H

void array_sort1(int *vec, int n);

#endif
