#ifndef EX18_H
#define EX18_H
void compress_shorts(short* shorts, int n_shorts, int* integers);
#endif
