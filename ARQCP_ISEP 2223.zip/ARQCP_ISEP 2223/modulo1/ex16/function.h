#ifndef EX16_H
#define EX16_H
char* where_exists(char* str1, char* str2);
#endif
