#ifndef EX02_H
#define EX02_H

void copy_vec(int *vec1, int *vec2, int n);

#endif 
