#ifndef EX05_H
#define EX05_H

void upper2(char *str);

#endif
